package playout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import maou.RouletteSelector;
import maou.SamurAIRule;

/**
 * プレイアウトを実行する
 * 不具合系AIの検知もここで。
 * 
 * @author taiyou
 *
 */
public class MultiMovePlayout {
	//----------------------------------------
	// メンバ変数
	//----------------------------------------

	//ルール
	SamurAIRule rule;

	private int knownScore[][];					//既知の状態。通常はrevealScoreでわかること＋自身の情報が確定しているだけ。
	private Map<Integer,List<Integer>> negoMap;	//隠蔽された交渉。再配分しないと行けないポイント
	private double victoryPoint[];				//二回計算される勝利点
	private int turn;								//プレイアウトする最初の一手の時のターン数
	private List<SmallMove> moveList;				//最初の一手
	private boolean checkForDebug;				//バグチェック用の処理を有効にするか否か

	private Map<Integer,Integer> allInPlayers;		//単一の投票先に投票し続けるタイプのAI(key=playerIdx value=targetIdx)
	
	//----------------------------------------
	// メソッド
	//----------------------------------------
	
	public MultiMovePlayout(
			int turn,
			List<SmallMove> moves,
			SamurAIRule rule,
			Map<Integer,List<Integer>> negoMap,
			int knownScore[][],
			double victoryPoint[],
			boolean checkForDebug
			){
		this.turn = turn;
		this.rule = rule;
		this.negoMap = negoMap;
		this.knownScore = knownScore;
		this.victoryPoint = Arrays.copyOf(victoryPoint,victoryPoint.length);
		this.moveList = moves;
		this.checkForDebug = checkForDebug;
		
		allInPlayers = new HashMap<Integer,Integer>();
	}

	static private Random rand = new Random(System.currentTimeMillis());

	final public int playout(){
		int realScore[][] = new int[rule.PlayerNum][rule.LanguageNum];
		for(int i=0;i<rule.PlayerNum;i++){
			realScore[i] = Arrays.copyOf(knownScore[i],rule.LanguageNum);
		}
		double currentVictoryPont[] = Arrays.copyOf(victoryPoint, victoryPoint.length);

		detectAITactics();
		estimateNightVote(realScore);
		estimateFirstVote(realScore);
		if(checkForDebug){
			checkUpperPoint(realScore,turn);
		}
		calcMidVictoryPoint(realScore, currentVictoryPont);
		
		estimateFutureVote(realScore, currentVictoryPont);
		if(checkForDebug){
			checkUpperPoint(realScore,rule.TurnNum-1);
		}
		int winner = calcVictoryPoint(realScore,currentVictoryPont);


		return winner;
	}
	
	/**
	 * 不具合系AIの検出
	 */
	final private void detectAITactics(){
		if(turn==0){
			return;
		}
		
		//threthold
		double threthold = 0.8;
		if(turn < 3){
			//やや情報が不足して乱暴な推論であるが、間違っていてもこのターンならそんなに損害なさそう。
			//反対に正しい時はメリット大きい気がする。
			threthold = 1.0;
			return;
		}

		int sum = 0;										//このターンまでの既知なスコア上限
		int nightMinVote[] = new int[rule.LanguageNum];	//投票先に対するターンごとの最小投票数。コレを数えておかないと複数人昼の条件を満たすが、夜の条件が満たされないケースに対応できない。
		int unknownNightCount = 0;	//未知な夜が何回今までにあったか
		for(int i=0;i<rule.LanguageNum;i++){
			nightMinVote[i]=Integer.MAX_VALUE;
		}
		//既知のスコアとしての上限
		for(int i=0;i<turn;i++){
			if(i%2==0 || (turn>=rule.MoreInfoOpenedTurn && i<=rule.MiddleScoringTurn)){
				sum += rule.friendlyPoint(i)*rule.negotiationCount(i);
			}else{
				int langCount[] = new int[rule.LanguageNum];
				for(int lang:negoMap.get(i)){
					langCount[lang]++;
				}
				for(int j=0;j<rule.LanguageNum;j++){
					nightMinVote[j]=Math.min(nightMinVote[j], langCount[j]);
				}
				unknownNightCount++;
			}
		}
		assert(unknownNightCount==negoMap.size());
		//夜の投票先としてこのようなAIに選択されていておかしくない場所
		
		for(int i=1;i<rule.PlayerNum;i++){
			for(int j=0;j<rule.LanguageNum;j++){
				if(knownScore[i][j] >= sum * threthold && nightMinVote[j] >= rule.HolidayNegotiationCount){
					//プレイヤーiは投票先jに全力で投票するAIとみなす
					allInPlayers.put(i, j);
					nightMinVote[j] -= rule.HolidayNegotiationCount;
					assert(nightMinVote[j]>=0);
					break;
				}
			}
		}
	}

	final private void estimateFutureVote(int[][] realScore, double[] currentVictoryPont) {
		RouletteSelector rs = new RouletteSelector(rule.Attensions, rand);
		RouletteSelector rs2[] = new RouletteSelector[rule.PlayerNum];
		for(int i=0;i<rule.PlayerNum;i++){
			int src2[] = new int[rule.LanguageNum];
			for(int j=0;j<rule.LanguageNum;j++){
				src2[j]=rule.Attensions[j]+realScore[i][j];
			}
			rs2[i]=new RouletteSelector(src2, rand);
		}
		
		for(int t=turn+1;t<rule.TurnNum;t++){
			//自分を含めて4人が乱数で選択するものとする
			//1つずつ乱数で選ぶのと、すでに完成している手候補の中から選ぶのとでは出来上がりの手が選択される確率が異なる
			//0 0 0 0 0 と 1 2 3 4 5 では後者のほうが5!倍作られやすい。どっちのほうがただしいだろう？
			for(int i=0;i<rule.PlayerNum;i++){
				int move[] = new int[rule.negotiationCount(t)];
				if(allInPlayers.get(i)!=null){
					//不具合系AI
					int tarLang = allInPlayers.get(i);
					for(int j=0;j<move.length;j++){
						move[j] = tarLang;
					}
				}else{
					for(int j=0;j<move.length;j++){
						move[j] = rs.select();
					}
				}
					
				for(int lang:move){
					realScore[i][lang]+=rule.friendlyPoint(t);
				}
			}
			if(t == rule.MiddleScoringTurn){
				if(checkForDebug){
					for(int i=0;i<rule.PlayerNum;i++){
						assert(currentVictoryPont[i]==0.0);
					}
				}
				calcVictoryPoint(realScore,currentVictoryPont);
			}
		}
	}

	final private void calcMidVictoryPoint(int[][] realScore,
			double[] currentVictoryPont) {
		//初手がちょうど中間勝利点がもらえるターンだった場合の計算
		if(turn==rule.MiddleScoringTurn){
			if(checkForDebug){
				for(int i=0;i<rule.PlayerNum;i++){
					int sum = 0;
					for(int j=0;j<rule.LanguageNum;j++){
						sum+=realScore[i][j];
					}
					assert(sum == 5+4+5+4+5);
					assert(currentVictoryPont[i]==0.0);
				}
			}
			calcVictoryPoint(realScore,currentVictoryPont);
		}
	}

	final private void checkUpperPoint(int[][] realScore,int checkTurn) {
		//ここまででこのターンまでの獲得状況が決定されているはずなので確認
		//必要なポイントの計算
		int realUpperPoint = 0;
		for(int i=0;i<=checkTurn;i++){
			realUpperPoint+=rule.friendlyPoint(i)*rule.negotiationCount(i);
		}

		for(int i=0;i<rule.PlayerNum;i++){
			int sum = 0;
			for(int p:realScore[i]){
				sum += p;
			}
			assert(sum==realUpperPoint);
		}
	}

	final private void estimateFirstVote(int[][] realScore) {
		//投票先が指定されている場合はそれに従う。
		//そうでない場合は経験的に良い結果となるものを使う
		int addPoint = rule.friendlyPoint(turn);

		
		for(int i=0;i<rule.PlayerNum;i++){
			SmallMove move = i<moveList.size()?moveList.get(i):null;
			int negoCount = rule.negotiationCount(turn);
			if(move!=null){	//投票先が指定されている
				for(int lang:moveList.get(i).move){
					realScore[i][lang] += addPoint;
				}
			}else if(allInPlayers.containsKey(i)){
				//不具合系AI
				int lang = allInPlayers.get(i);
				for(int j=0;j<negoCount;j++){
					realScore[i][lang] += addPoint;
				}
			}else{
				//指定されていない
				RouletteSelector rs = new RouletteSelector(realScore[i], rand);
				for(int j=0;j<negoCount;j++){
					//一定確率で今までの投資金額を優先するルーレット選択を考える
					int selectedLang = rs.select();
					realScore[i][selectedLang] += addPoint;
				}
			}
		}
	}

	final private void estimateNightVote(int[][] realScore) {
		//未配分を乱数で確定させる。
		//不足分は次の２つ
		//1.休日で隠蔽されていた情報(negoMapに入っている)
		//2.childNodeListが作られた時に自身の手は反映させたが、敵の行動がまだ反映できていない

		//1ではどの言語に入ったかは考えられているが誰がそこに入れたかはわからない。
		//2では誰が投票すべきかはわかるが、どの言語に投票したかは真には決定できない
		if(negoMap != null){
			for(Entry<Integer, List<Integer>>entry: negoMap.entrySet()){
				if(entry.getValue()!=null){
					int checkTurn = entry.getKey();
					int eachNegoCount = rule.negotiationCount(checkTurn);
					int point = rule.friendlyPoint(checkTurn);
					List<Integer> negoList = new ArrayList<Integer>(entry.getValue());

					boolean isDonePlayer[] = new boolean[rule.PlayerNum];
					//先に不具合系AIの処理をする
					for(Entry<Integer,Integer> allIn: allInPlayers.entrySet()){
						for(int j=0;j<eachNegoCount;j++){
							boolean removed = negoList.remove(allIn.getValue());
							assert(removed);
							realScore[allIn.getKey()][allIn.getValue()] += point;
						}
						isDonePlayer[allIn.getKey()] = true;
					}
					
					//完全にランダムに取る
					for(int i=1;i<rule.PlayerNum;i++){
						if(isDonePlayer[i]){
							continue;
						}
						for(int j=0;j<eachNegoCount;j++){
							int lang = negoList.remove((int)rand.nextInt(negoList.size()));
							realScore[i][lang] += point;
						}
					}
					assert(negoList.isEmpty());

				}
			}
		}
	}
	
	final static public double[] calcVictoryPoint(int realScore[][], SamurAIRule rule){
		double ret[] = new double[rule.PlayerNum];
		for(int lang = 0;lang < rule.LanguageNum;lang++){
			List<Integer> minPlayerIdxList = new ArrayList<Integer>();
			int minFriendlyPoint = Integer.MAX_VALUE;
			List<Integer> maxPlayerIdxList = new ArrayList<Integer>();
			int maxFriendlyPoint = Integer.MIN_VALUE;
			for(int i=0;i<rule.PlayerNum;i++){
				int friendlyPoint = realScore[i][lang];

				if(minFriendlyPoint >= friendlyPoint){
					if(minFriendlyPoint > friendlyPoint){
						minPlayerIdxList.clear();
						minFriendlyPoint = friendlyPoint;
					}
					minPlayerIdxList.add(i);
				}
				if(maxFriendlyPoint <= friendlyPoint){
					if(maxFriendlyPoint < friendlyPoint){
						maxPlayerIdxList.clear();
						maxFriendlyPoint = friendlyPoint;
					}
					maxPlayerIdxList.add(i);
				}
			}
			for(int i:maxPlayerIdxList){
				ret[i] += rule.Attensions[lang] / (double)maxPlayerIdxList.size();
			}
			for(int i:minPlayerIdxList){
				ret[i] -= rule.Attensions[lang] / (double)minPlayerIdxList.size();
			}
		}
		return ret;
	}

	final private int calcVictoryPoint(int realScore[][],double currentVictoryPont[]){
		double tmpVictoryPoint[] = calcVictoryPoint(realScore,rule);
		for(int i=0;i<currentVictoryPont.length;i++){
			currentVictoryPont[i] += tmpVictoryPoint[i];
		}

		List<Integer> winnerList = new ArrayList<Integer>();
		double winnersScore = Double.NEGATIVE_INFINITY;
		for(int i=0;i<rule.PlayerNum;i++){
			double score = currentVictoryPont[i];
			if(winnersScore <= score){
				if(winnersScore < score){
					winnerList.clear();
					winnersScore = score;
				}
				winnerList.add(i);
			}
		}

		if(winnerList.size()==1){
			return winnerList.get(0);
		}else{
			return -1;
		}
	}

	final boolean isWeekday(){
		return turn%2==0;
	}

}
