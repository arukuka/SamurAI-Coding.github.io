/**
 * Created by capri_000 on 2016/01/02.
 */
public interface Builder<T> {
  T build();
}
