package maou;

import java.util.Arrays;
import java.util.List;
import java.util.Random;


/**
 * 整数型のルーレット選択
 * 
 * @author taiyou
 *
 */
public class RouletteSelector {
	private Random rand;
	
	private int totalNum = 0;
	private int array[];
	private int label[];

	private static int[] toIntArray(List<Integer> src){
		int[] ret = new int[src.size()];
		for(int i=0;i<src.size();i++){
			ret[i]=src.get(i);
		}
		return ret;
	}
	
	public RouletteSelector(int[] array,Random rand) {
		this(array,null,rand);
	}
			
	public RouletteSelector(int[] array,int label[],Random rand) {
		this.array = Arrays.copyOf(array, array.length);
		this.label = label;
		for(int i:array){
			totalNum += i;
		}
		this.rand = rand;
	}
	
	public RouletteSelector(List<Integer> weightList, List<Integer> labelList,Random rand){
		this(toIntArray(weightList),toIntArray(labelList),rand);
	}
	
	public int select(){
		if(totalNum==0){
			int idx = rand.nextInt(array.length);
			if(label==null){
				return idx;
			}else{
				return label[idx];
			}
		}
		int num = rand.nextInt(totalNum);
		int total = 0;
		for(int idx=0;idx<array.length;idx++){
			total += array[idx];
			if(total > num){
				if(label==null){
					return idx;
				}else{
					return label[idx];
				}
			}
		}
		return -1;
	}

	public static void main(String argv[]){
		RouletteSelector rs = new RouletteSelector(new int[]{1,2,3,4,5,6}, new Random());
		int sum[] = new int[6];
		for(int i=0;i<1000;i++){
			sum[rs.select()]++;
		}
		for(int i=0;i<6;i++){
			System.out.println(i+":"+sum[i]);
		}
		
	}
	
}
