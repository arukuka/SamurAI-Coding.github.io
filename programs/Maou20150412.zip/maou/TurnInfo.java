package maou;

import java.util.Arrays;


/**
 * ターンごとの情報
 * 送られてくるテキストをパースして保持する
 * フォーマットはCodeFestivalとSamuraCoding両対応
 * @author taiyou
 *
 */
public class TurnInfo {
	public TurnInfo(String rawText,SamurAIRule rule){
		this.Rule = rule;
		String[] line = rawText.split("\n");
		String line0[] = line[0].split(" ");
		CurrentTurn = Integer.parseInt(line0[0])-1;
		IsWeekday   = line0[1].equals("D")||line0[1].equals("W");
		RevealedFriendlyPoint = new int[rule.PlayerNum][rule.LanguageNum];
		for(int i=0;i<rule.LanguageNum;i++){
			String curLine[] = line[1+i].split(" ");
			assert(rule.PlayerNum == rule.PlayerNum);
			for(int j=0;j<rule.PlayerNum;j++){
				RevealedFriendlyPoint[j][i] = Integer.parseInt(curLine[j]);
			}
		}
		String rfLine[] = line[rule.LanguageNum+1].split(" ");
		RealFriendlyPoint = new int[rule.LanguageNum];
		for(int i=0;i<rule.LanguageNum;i++){
			RealFriendlyPoint[i] = Integer.parseInt(rfLine[i]);
		}
		NegotiatedCount = new int[rule.LanguageNum];
		if(IsWeekday){
			String[] ngLine = line[rule.LanguageNum+2].split(" ");
			for(int i=0;i<rule.LanguageNum;i++){
				NegotiatedCount[i] = Integer.parseInt(ngLine[i]);
			}
		}else{
			Arrays.fill(NegotiatedCount, -1);
		}
	}
	
	public TurnInfo(SamurAIRule rule,int currentTurn,boolean isWeekDay, int revealedFriendlyPoint[][],int realFriendlyPoint[],int negotiatedCount[]){
		Rule = rule;
		CurrentTurn = currentTurn;
		IsWeekday = isWeekDay;
		RevealedFriendlyPoint = new int[Rule.PlayerNum][Rule.LanguageNum];
		for(int i=0;i<Rule.PlayerNum;i++){
			System.arraycopy(revealedFriendlyPoint[i], 0, RevealedFriendlyPoint[i], 0, Rule.LanguageNum);
		}
		RealFriendlyPoint = new int[Rule.LanguageNum];
		System.arraycopy(realFriendlyPoint, 0, RealFriendlyPoint, 0, Rule.LanguageNum);
		NegotiatedCount = new int[Rule.LanguageNum];
		System.arraycopy(negotiatedCount, 0, NegotiatedCount, 0, Rule.LanguageNum);
	}

	public final SamurAIRule Rule;
	
	public final int CurrentTurn;
	public final boolean IsWeekday;
	public final int RevealedFriendlyPoint[][];	//[Player][Language]の順で格納された公開された信者数
	public final int RealFriendlyPoint[];			//各言語に対しての真の信者数
	public final int NegotiatedCount[];			//各言語に対して前日の休日に普及をされた回数(平日のみ有効な値)

	public int currentNegotiationCount(){
		return IsWeekday?Rule.WeekdayNegotiationCount:Rule.HolidayNegotiationCount;
	}
	public int currentFriendlyPoint(){
		return IsWeekday?Rule.WeekdayFriendlyPoint:Rule.HolidayFriendlyPoint;
	}
}
