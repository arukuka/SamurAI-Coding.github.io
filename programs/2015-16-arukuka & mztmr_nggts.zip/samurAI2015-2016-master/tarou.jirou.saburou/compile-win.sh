dmd src/*.d -ofout/main -O -release -inline -boundscheck=off
