javac jamurai/*.java
