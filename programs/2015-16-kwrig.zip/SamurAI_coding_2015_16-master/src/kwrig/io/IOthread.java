package kwrig.io;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Created by kwrig on 2016/01/20.
 */
public class IOthread implements Runnable , KeyListener{


    public IOthread(){

    }


    @Override
    public void run() {

    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
