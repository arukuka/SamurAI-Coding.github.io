package playout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 手とその評価値を保持する
 * @author taiyou
 *
 */
public class SmallMove{
	final public int move[];
	//プレイアウトに関するもの
	private double scoreSum = 0.0;
	private double scorePowSum = 0.0;
	private int count = 0;
	
	/* マルチスレッド化した時の名残。
	private double orgScoreSum;
	private double orgScorePowSum;
	private int orgCount;
	
	public SmallMove(SmallMove src){
		this.move = Arrays.copyOf(src.move, src.move.length);
		this.scorePowSum = src.scorePowSum;
		this.count = src.count;
		this.scoreSum = src.scoreSum;
		orgCount = count;
		orgScorePowSum = scorePowSum;
		orgScoreSum = scoreSum;
	}
	
	public void merge(SmallMove src){
		src.move.equals(this.move);
		this.scorePowSum += src.scorePowSum - src.orgScorePowSum;
		this.scoreSum += src.scoreSum - src.orgScoreSum;
		this.count += src.count - src.orgCount;
	}
	*/
	
	public SmallMove(int move[]){
		this.move = Arrays.copyOf(move, move.length);
	}
	
	final public void feedBack(double score){
		scoreSum += score;
		scorePowSum += score * score;
		count++;
	}
	
	final public int getCount(){
		return count;
	}
	
	final public double ucb1tune(int totalPlayCount){
		if(count==0){
			return Double.POSITIVE_INFINITY;
		}
		double avr = scoreSum/count;
		double x   = Math.log(totalPlayCount)/count;
		return avr + Math.sqrt(x * Math.min(0.25, scorePowSum/count - avr*avr+Math.sqrt(2*x)));
	}
	
	private static int WeekdayMoves[][];
	private static int HolidayMoves[][];

	public static void makeMove(){
		if(WeekdayMoves!=null){
			return;
		}

		WeekdayMoves = new int[252][5];
		int num = 0;
		for(int a=0;a<6;a++){
			for(int b=a;b<6;b++){
				for(int c=b;c<6;c++){
					for(int d=c;d<6;d++){
						for(int e=d;e<6;e++){
							WeekdayMoves[num++]=new int[]{a,b,c,d,e};
						}
					}
				}
			}
		}
		assert(num==252);

		num = 0;
		if(HolidayMoves != null){
			return;
		}
		HolidayMoves = new int[21][2];
		for(int a=0;a<6;a++){
			for(int b=a;b<6;b++){
				HolidayMoves[num++]=new int[]{a,b};
			}
		}
		assert(num==21);
	}
	
	public void print(){
		System.out.println("手:"+Arrays.toString(move)+",選択回数:"+count+",勝率:"+scoreSum/count);
	}
	
	public static List<SmallMove> createMoveList(int turn){
		return turn%2==0?createWeekdayMoveList():createHolidayMoveList();
	}
	public static List<SmallMove> createHolidayMoveList(){
		makeMove();
		List<SmallMove> ret = new ArrayList<SmallMove>(21);
		for(int[] move:HolidayMoves){
			ret.add(new SmallMove(move));
		}
		return ret;
	}
	public static List<SmallMove> createWeekdayMoveList(){
		makeMove();
		List<SmallMove> ret = new ArrayList<SmallMove>(252);
		for(int[] move:WeekdayMoves){
			ret.add(new SmallMove(move));
		}
		return ret;
	}
	static public int[][] getRawMove(int turn){
		makeMove();
		return turn%2==0?WeekdayMoves:HolidayMoves;
	}
}
