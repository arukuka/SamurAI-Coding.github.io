package maou;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 事前に時間をかけてモンテカルロ探索しておいた最初の１手のテーブル
 * 
 * @author taiyou
 *
 */
public class FirstBoost {
	public FirstBoost() {
		insert(new int[]{3,3,3,3,3,3},new int[]{0,1,2,4,5});
		insert(new int[]{3,3,3,3,3,4},new int[]{0,5,5,5,5});
		insert(new int[]{3,3,3,3,3,5},new int[]{5,5,5,5,5});
		insert(new int[]{3,3,3,3,3,6},new int[]{5,5,5,5,5});
		insert(new int[]{3,3,3,3,4,4},new int[]{4,4,4,5,5});
		insert(new int[]{3,3,3,3,4,5},new int[]{4,5,5,5,5});
		insert(new int[]{3,3,3,3,4,6},new int[]{5,5,5,5,5});
		insert(new int[]{3,3,3,3,5,5},new int[]{4,4,4,5,5});
		insert(new int[]{3,3,3,3,5,6},new int[]{4,5,5,5,5});
		insert(new int[]{3,3,3,3,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,3,3,4,4,4},new int[]{3,4,4,5,5});
		insert(new int[]{3,3,3,4,4,5},new int[]{4,5,5,5,5});
		insert(new int[]{3,3,3,4,4,6},new int[]{5,5,5,5,5});
		insert(new int[]{3,3,3,4,5,5},new int[]{4,4,5,5,5});
		insert(new int[]{3,3,3,4,5,6},new int[]{4,5,5,5,5});
		insert(new int[]{3,3,3,4,6,6},new int[]{4,4,5,5,5});
		insert(new int[]{3,3,3,5,5,5},new int[]{3,4,4,5,5});
		insert(new int[]{3,3,3,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{3,3,3,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,3,3,6,6,6},new int[]{3,4,4,5,5});
		insert(new int[]{3,3,4,4,4,4},new int[]{2,2,3,4,5});
		insert(new int[]{3,3,4,4,4,5},new int[]{2,3,5,5,5});
		insert(new int[]{3,3,4,4,4,6},new int[]{5,5,5,5,5});
		insert(new int[]{3,3,4,4,5,5},new int[]{4,4,5,5,5});
		insert(new int[]{3,3,4,4,5,6},new int[]{4,5,5,5,5});
		insert(new int[]{3,3,4,4,6,6},new int[]{4,4,5,5,5});
		insert(new int[]{3,3,4,5,5,5},new int[]{3,4,4,5,5});
		insert(new int[]{3,3,4,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{3,3,4,5,6,6},new int[]{4,4,5,5,5});
		insert(new int[]{3,3,4,6,6,6},new int[]{3,3,4,5,5});
		insert(new int[]{3,3,5,5,5,5},new int[]{2,2,3,4,5});
		insert(new int[]{3,3,5,5,5,6},new int[]{2,3,5,5,5});
		insert(new int[]{3,3,5,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,3,5,6,6,6},new int[]{3,3,4,4,5});
		insert(new int[]{3,3,6,6,6,6},new int[]{2,3,4,5,5});
		insert(new int[]{3,4,4,4,4,4},new int[]{1,2,3,4,5});
		insert(new int[]{3,4,4,4,4,5},new int[]{2,4,5,5,5});
		insert(new int[]{3,4,4,4,4,6},new int[]{1,5,5,5,5});
		insert(new int[]{3,4,4,4,5,5},new int[]{4,4,5,5,5});
		insert(new int[]{3,4,4,4,5,6},new int[]{4,4,5,5,5});
		insert(new int[]{3,4,4,4,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,4,4,5,5,5},new int[]{3,3,4,4,5});
		insert(new int[]{3,4,4,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{3,4,4,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,4,4,6,6,6},new int[]{3,3,4,4,5});
		insert(new int[]{3,4,5,5,5,5},new int[]{2,3,3,4,5});
		insert(new int[]{3,4,5,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{3,4,5,5,6,6},new int[]{4,4,5,5,5});
		insert(new int[]{3,4,5,6,6,6},new int[]{3,3,4,4,5});
		insert(new int[]{3,4,6,6,6,6},new int[]{2,2,3,4,5});
		insert(new int[]{3,5,5,5,5,5},new int[]{1,2,3,4,5});
		insert(new int[]{3,5,5,5,5,6},new int[]{1,3,5,5,5});
		insert(new int[]{3,5,5,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{3,5,5,6,6,6},new int[]{3,4,4,5,5});
		insert(new int[]{3,5,6,6,6,6},new int[]{2,2,3,4,5});
		insert(new int[]{3,6,6,6,6,6},new int[]{1,2,3,4,5});
		insert(new int[]{4,4,4,4,4,4},new int[]{0,2,3,4,5});
		insert(new int[]{4,4,4,4,4,5},new int[]{0,2,5,5,5});
		insert(new int[]{4,4,4,4,4,6},new int[]{4,5,5,5,5});
		insert(new int[]{4,4,4,4,5,5},new int[]{4,4,5,5,5});
		insert(new int[]{4,4,4,4,5,6},new int[]{4,4,5,5,5});
		insert(new int[]{4,4,4,4,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{4,4,4,5,5,5},new int[]{3,4,4,5,5});
		insert(new int[]{4,4,4,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{4,4,4,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{4,4,4,6,6,6},new int[]{3,4,4,5,5});
		insert(new int[]{4,4,5,5,5,5},new int[]{2,2,3,4,5});
		insert(new int[]{4,4,5,5,5,6},new int[]{3,4,5,5,5});
		insert(new int[]{4,4,5,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{4,4,5,6,6,6},new int[]{3,4,4,5,5});
		insert(new int[]{4,4,6,6,6,6},new int[]{2,3,3,4,5});
		insert(new int[]{4,5,5,5,5,5},new int[]{1,2,3,4,5});
		insert(new int[]{4,5,5,5,5,6},new int[]{1,4,5,5,5});
		insert(new int[]{4,5,5,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{4,5,5,6,6,6},new int[]{3,3,4,4,5});
		insert(new int[]{4,5,6,6,6,6},new int[]{2,3,4,5,5});
		insert(new int[]{4,6,6,6,6,6},new int[]{1,2,3,4,5});
		insert(new int[]{5,5,5,5,5,5},new int[]{0,2,3,4,5});
		insert(new int[]{5,5,5,5,5,6},new int[]{2,4,5,5,5});
		insert(new int[]{5,5,5,5,6,6},new int[]{4,4,4,5,5});
		insert(new int[]{5,5,5,6,6,6},new int[]{3,3,4,4,5});
		insert(new int[]{5,5,6,6,6,6},new int[]{2,3,3,4,5});
		insert(new int[]{5,6,6,6,6,6},new int[]{1,2,3,4,5});
		insert(new int[]{6,6,6,6,6,6},new int[]{0,1,3,4,5});

	}
	
	private void insert(int[] key, int[] move){
		Arrays.sort(key);
		MoveMap.put(Arrays.hashCode(key),move);
	}
	
	/**
	 * keyに対する事前計算によるベストな解を返す
	 * 並び替えなどは関数内でいい感じにやって正しく対応した手を返す。
	 * @param key
	 * @return
	 */
	public int[] get(int[] key){
		int sorted[] = Arrays.copyOf(key, key.length);
		Arrays.sort(sorted);
		int move[] = MoveMap.get(Arrays.hashCode(sorted));
		//moveを並び替える前の対応関係に戻すための対応表
		int unsort[] = new int[key.length];
		
		int findIdx = 0;
		for(int i=0;i<sorted.length;i++){	//sortedは昇順に並んでいるはず
			if(i>0){
				if(sorted[i-1] != sorted[i]){
					findIdx = 0;
				}
			}
			for(int j=findIdx;j<key.length;j++){
				if(key[j]==sorted[i]){
					findIdx=j+1;
					unsort[i]=j;
					break;
				}
			}
		}
		int ret[] = new int[move.length];
		for(int i=0;i<move.length;i++){
			ret[i] = unsort[move[i]];
		}
		
		
		return ret;
	}
	
	public static void main(String argv[]){
		//test
		FirstBoost boost = new FirstBoost();
		System.out.println(Arrays.toString(boost.get(new int[]{6,3,5,3,4,5})));
	}
	
	public Map<Integer,int[]> MoveMap = new HashMap<Integer,int[]>();

}
