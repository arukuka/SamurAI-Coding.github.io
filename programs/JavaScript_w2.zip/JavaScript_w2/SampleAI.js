var startTime = Date.now(),
    lineCount = 0,
    initialized = false,
    isHoliday = 0,
    turn = 0,
    turn_cou=0,
    players_cou=0,
    targets_cou=0,
    ponits=[],
    points2=[],
    total_point=0,
    time_limit=950,
    my_atk=[],
    opp_atk=[],
    atk=[],
    atk_log=[],
    stl=[],
    stl2=[],
    my_stl=[],
    my_stl2=[],
    rank=[],
    score=[],
    fixed_rank=[],
    fixed_score=[],
    point_c=0,
    point_id=[],
    point_id2=[],
    odor_id=[],
    atk_id=[],
    exist=[0,0,0,0],
    order=[1,2,3],
    c=[],
    c2=[],
    c3=[],
    c_id=[],
    c2_id=[],
    c3_id=[],
    loop_limit=200,
    readline = require('readline'),
    rl = readline.createInterface(process.stdin, process.stdout),
    info=[],
    debug=0;

function comb(p,p2,id,id2,p3,id3){
  var t=[0,0,0, 0,0,0];
  var l=5;
  var incr=function(n){
    t[n]++;
    if (n===l && t[n]===l+1){return;}
    if (t[n]===6){
      t[n]=0;
      if (!incr(n+1)){return;}
    }
    return 1;
  }
  while(incr(0)){
    if (t[0]+t[1]+t[2]+t[3]+t[4]+t[5]===5 && t.filter(function(x) {if (x===0){return 1;}}).length>=0){p3.push(t.concat());id3.push(p3.length-1);}
    if (t[0]+t[1]+t[2]+t[3]+t[4]+t[5]===5 && t.filter(function(x) {if (x===0){return 1;}}).length>=3){p.push(t.concat());id.push(p.length-1);}
    if (t[0]+t[1]+t[2]+t[3]+t[4]+t[5]===4 && t.indexOf(1)<0 && t.indexOf(3)<0 && t.indexOf(5)<0){p2.push(t.concat());id2.push(p2.length-1);}
  }
//  add_info("conb",p2.length,p2);
}

function add_info(){
  if (!debug){return;}
  var t=[];
  for (var i=0;i<arguments.length;i++) {
    t.push(arguments[i]);
  }
  info.push(t.concat());
}


rl.setPrompt("");
send_msg("READY\n");

rl.on('line', function (line) {
  lineCount++;
  var i=0,
      val=line.split(" ");
  for (i=0;i<val.length;i++){
    val[i]=parseInt(val[i],10);
  }
  if (!initialized) {
    if (lineCount == 1) {
      startTime = Date.now();
      turn_cou = val[0],
      players_cou = val[1],
      targets_cou = val[2];
      for (i=0;i<targets_cou;i++){
           atk[i]=[];
           stl[i]=0;
           stl2[i]=0;
           my_stl[i]=0;
           my_stl2[i]=0;
      }
      for (i=0;i<players_cou;i++){
           score[i]=0;
           rank[i]=i;
           fixed_score[i]=0;
           fixed_rank[i]=i;
      }
    }
    else if (lineCount == 2) {
      points=val.concat();
      for (i=0;i<points.length;i++){point_id[i]=i;odor_id[i]=i;point_id2[i]=i;}
      point_id.sort(function(a,b){return(points[b]-points[a]);});
      initialized = true;
      lineCount=0;
    }
  }
  else {
    if (lineCount==1) {
      if (turn>0){startTime = Date.now();}
      atk_log[turn]=[[],[],[],[],[],[]];
      if (turn===0){comb(c,c2,c_id,c2_id,c3,c3_id);}
    }
    else if (2 <= lineCount && lineCount <= 7 ) {
      for (i=0;i<players_cou;i++){
        atk[lineCount-2][i]=val[i];
        atk_log[turn][lineCount-2][i]=val[i];
      }
    }
    else if (lineCount == 8) {
      for (i=0;i<targets_cou;i++){
        my_atk[i]=val[i];
      }
      if (isHoliday){
        dateHoliday();
        turn_end();
      }
    }
    else {
      for (i=0;i<targets_cou;i++){
        if (turn===2 || turn===6){stl[i]=val[i];}
        else{stl2[i]=val[i];}
      }
      dateWeekday();
      turn_end();
    }
  }
  if (turn == turn_cou) {
    rl.close();
  }
});

function chk_kill(){
  var i=0,
      kill=0;
  for (i=1;i<players_cou;i++){
    if (turn===3 && atk_log[turn][0][i]-atk_log[turn-3][0][i]>=10){exist[i]=1;kill=1;}
    else if (turn===5 && atk_log[turn][0][i]-atk_log[turn-3][0][i]>=12){exist[i]=1;kill=1;}
    else if (turn===7 && atk_log[turn][0][i]-atk_log[turn-3][0][i]>=12){exist[i]=1;kill=1;}
    else{exist[i]=0;}
  }
  if (kill===1){exist[0]=1;}
  else{exist[0]=0;}
  order.sort(function(a, b) {
      if (exist[a] > exist[b]) return -1;
      if (exist[a] < exist[b]) return 1;
  });
/*
  for (i=0;i<targets_cou;i++){
    for (j=0;j<exist.length;j++){
      n=exist[j];
      if (atk[i][n]>0){cou[n]++;}
    }
  }
  exist.sort(function(a, b) {
      if (cou[exist[a]] < cou[exist[b]]) return -1;
      if (cou[exist[a]] > cou[exist[b]]) return 1;
  });
*/
}

function test(){
  var i=0,
      j=0,
      pat_id=0,
      s1=0,
      s2=0,
      data=[],
      data2=[],
      id2=[],
      s=score.concat(),
      r=rank.concat(),
      p=c,
      tp=[],
      p_=[c,c,c,c],
      id=[],
      tid=[],
      prev_pat=[],
      atk_pat=[],
      fire=[],
      l=0,
      margin1=[0,0,0, 0,0,0],
      margin2=[0,0,0, 0,0,0],
      margin3=[0,0,0, 0,0,0],
      margin_id=[],
      odor=[0,0,0, 0,0,0],
      max=[0,0,0, 0,0,0],
      acou=0,
      cou=0,
      ts=0,
      total=0,
      worse=0,
      awake=0;
  if (turn===3 || turn===5 || turn===7){chk_kill();}
//  add_info("exist",exist,order);
  for (i=0;i<targets_cou;i++){
    if (my_atk[i]>0){acou++;}
    odor[i]=atk[i][1]+atk[i][2]+atk[i][3]+(stl[i]-my_stl[i])*2+(stl2[i]-my_stl2[i])*2;
    ts=0;
    if (stl[i]-my_stl[i]===1){ts+=2;}
    else if (stl[i]-my_stl[i]>=2){ts+=4;}
    if (stl2[i]-my_stl2[i]===1){ts+=2;}
    else if (stl2[i]-my_stl2[i]>=2){ts+=4;}
    max[i]=my_atk[i];
    for (j=1;j<players_cou;j++){
      if (max[i]<atk[i][j]+ts){max[i]=atk[i][j]+ts;}
      if (my_atk[i]>atk[i][j]+ts && margin1[i]<my_atk[i]-atk[i][j]-ts){margin1[i]=my_atk[i]-atk[i][j]-ts;}
      if (margin2[i]<atk[i][j]+ts-my_atk[i]){margin2[i]=atk[i][j]+ts-my_atk[i];}
      if (my_atk[i]<atk[i][j]+ts && (margin3[i]===0 || margin3[i]>atk[i][j]+ts-my_atk[i])){margin3[i]=atk[i][j]+ts-my_atk[i];}
    }
    if (max[i]===0){points2[i]=points[i];}
    else{points2[i]=points[i]/max[i];}
  }
  point_id2.sort(function(a,b){return(points2[b]-points2[a]);});
  odor_id.sort(function(a,b){
      if (odor[b]<odor[a]){return -1;}
      if (odor[b]>odor[a]){return 1;}
  });
if (turn===5){atk_id=odor_id.concat();}


add_info("m o",margin1,margin2,margin3,odor,odor_id);
add_info("max points2",points,max,points2,point_id2);
/*
  if (turn===0){
    return [point_id[2],point_id[2],point_id[2],point_id[3],point_id[4]];
  }
  else if (turn===1){
    return [point_id[3],point_id[4]];
  }
*/
/*
  else if (turn===2){
    return [point_id[1],point_id[4],point_id[4],point_id[4],point_id[4]];
  }
  else if (turn===3){
//    return [point_id[3],point_id[4]];
  }
*/
  if (isHoliday){
    p=c2;
    p_=[c2,c2,c2,c2],
    id2=c2_id.concat();
    id=[c2_id.concat(),c2_id.concat(),c2_id.concat(),c2_id.concat()];
  }
  else{
    id2=c_id.concat();
    id=[c_id.concat(),c_id.concat(),c_id.concat(),c_id.concat()];
  }
  if (turn===5){
    battle(atk,s,r);
    for (i=0;i<players_cou;i++){
        fixed_rank[i]=r[i];
        fixed_score[i]=s[i];
    }
//    add_info("s,r",fixed_rank,fixed_score);
  }
  i=points[point_id[0]]+points[point_id[1]]+points[point_id[5]]-points[point_id[2]]-points[point_id[3]]-points[point_id[4]];
  if (i>0){worse=1;}
  i=0;
  if (turn>2 && worse===1){
//    total=odor[point_id[0]]+odor[point_id[1]]+odor[point_id[2]]+odor[point_id[3]]+odor[point_id[4]]+odor[point_id[5]];
//    if (total>0 && odor[point_id[2]]+odor[point_id[3]]+odor[point_id[4]]>=total/2){awake=1;}
    if (odor_id[0]===point_id[2] || odor_id[1]===point_id[2] || odor_id[2]===point_id[2]){i++;}
    if (odor_id[0]===point_id[3] || odor_id[1]===point_id[3] || odor_id[2]===point_id[3]){i++;}
    if (odor_id[0]===point_id[4] || odor_id[1]===point_id[4] || odor_id[2]===point_id[4]){i++;}
    if (i>=2){awake=1;}
  }
 add_info("fixed_score",fixed_score[0],fixed_score[fixed_rank[0]],fixed_rank,fixed_score);

  add_info("awake worse",awake,worse);
  l=p.length;
  loop: for (i=0;i<l;i++){
      if (turn<3){
        if (worse===1 && my_atk[point_id[4]]+p[i][point_id[4]]>4){continue;}
        if (worse===1 && my_atk[point_id[3]]+p[i][point_id[3]]>4){continue;}
      }
      if (turn>1 && turn<4 && worse===1){
        for (j=0; j<targets_cou; j++){
          if (my_atk[j]>odor[j] && p[i][j]>0){continue loop;}
          if (points[j]===3 && margin1[j]>1 && p[i][j]>0){continue loop;}
        }
      }
      if (turn<4){
        if (awake===0 && exist[0]===0){

          if (p[i][point_id[0]]>0){continue;}
          if (p[i][point_id[1]]>0){continue;}
          if (p[i][point_id[5]]>0){continue;}

        }
      }
      if (turn===4){
        if (exist[0]===1){}
        else if (awake===1 && acou>3){
          for (j=0; j<targets_cou; j++){
            if (my_atk[j]===0 && p[i][j]>0){continue loop;}
          }
        }
        else {
          for (j=0; j<targets_cou; j++){
            if (margin1[j]>2 && odor[j]/3>3 && my_atk[j]===0 && p[i][j]>0){continue loop;}
          }
//          if ((odor_id[0]===point_id[2] || odor_id[1]===point_id[2] || odor_id[2]===point_id[2]) && p[i][point_id[2]]===0){continue}
        }
      }
      if (turn>4 && turn!==8 && fixed_score[0]===fixed_score[fixed_rank[0]]){
        for (j=0; j<targets_cou; j++){
          if (my_atk[j]===0 && p[i][j]>0){continue loop;}
        }
      }
      else if (turn>4 && turn<7){
          for (j=0; j<targets_cou; j++){
            if (odor[j]/3>3 && my_atk[j]===0 && p[i][j]>0){continue loop;}
          }
      }
      if (turn===4){
//        if (p[i].filter(function(x) {if (x===0){return 1;}}).length<4){continue}
      }
      if (turn===8){
//        if (p[i].filter(function(x) {if (x===0){return 1;}}).length<4){continue}
      }


      tp[tp.length]=p[i];
//      tid[tid.length]=id[i];
  }
  if (tp.length===0){tp=p;}
  p_[0]=tp;
  p=tp;
//  id[0]=tid;
  add_info("p",tp.length,tp);

//  
/*
  for (i=1; i<players_cou; i++){
    prev_pat=[];
    data=[];
    for (j=0;j<p_[i].length;j++){
      data[j]={"s":0,"w":0,"v":0,"l":0};
    }
    cou=0;
//    for (j=0;j<1;j++){
    while(1){
      cou++;
      test2(i,p_,data,prev_pat,r);
      if (cou>100 && Date.now()-startTime>200*i){
        break;
      }
    }
 add_info("loop",i,cou);
    id[i].sort(function(a,b){
      if (data[b].v<data[a].v){return -1;}
      if (data[b].v>data[a].v){return 1;}
    });
    atk_pat[i]=[];
    for (j=0;j<5;j++){
      atk_pat[i][j]=p_[i][[id[i][j]]];
    }
     // atk_pat[i]=[ p[id[i][0]], p[id[i][1]], p[id[i][2]], p[id[i][3]], p[id[i][4]] ];
  }
*/

/*
["atkpat",[
[
[0,0,5,0,0,0],[0,0,4,1,0,0],[0,0,3,2,0,0],[0,0,2,3,0,0],[0,0,1,4,0,0],[0,0,0,5,0,0],[0,0,4,0,1,0],[0,0,3,1,1,0],[0,0,2,2,1,0],[0,0,1,3,1,0],[0,0,0,4,1,0],[0,0,3,0,2,0],[0,0,2,1,2,0],[0,0,1,2,2,0],[0,0,0,3,2,0],[0,0,2,0,3,0],[0,0,1,1,3,0],[0,0,0,2,3,0],[0,0,1,0,4,0],[0,0,0,1,4,0],[0,0,0,0,5,0]],
[null,null,null,null,null],[null,null,null,null,null],[null,null,null,null,null]
]]


*/
  prev_pat=[];
  data=[];
  cou=0;
  for (j=0;j<p.length;j++){
      data[j]={"s":0,"w":0,"v":0,"l":0};
      data2[j]={"s":0,"w":0,"v":0,"l":0};
      tid[j]=j
  }
  id[0]=tid;

// add_info("atkpat",atk_pat);

//  for (i=0;i<1;i++){
  atk_pat[0]=p;
/*
  while(1){
    cou++;
    test2(0,atk_pat,data,prev_pat,r);
    if (cou>100 && Date.now()-startTime>750){
      break;
    }
  }
*/
//  add_info("cou1",cou);
/*
  id2.sort(function(a,b){
      if (data2[b].v<data2[a].v){return -1;}
      if (data2[b].v>data2[a].v){return 1;}
  });
  add_info("data2",cou);
*/
// add_info("stl",stl.concat(),stl2.concat(),my_stl.concat(),my_stl2.concat());
  cou=0;
//  for (i=0;i<3;i++){
  while(1){
    cou++;
    test2(0,p_,data,prev_pat,r,margin1,margin2,odor);
    if (cou>100 && Date.now()-startTime>time_limit){
      break;
    }
  }
  add_info("cou2",cou);


// add_info("atk_pat",atk_pat[1],atk_pat[2],atk_pat[3]);

  id[0].sort(function(a,b){
      if (data[b].v<data[a].v){return -1;}
      if (data[b].v>data[a].v){return 1;}
/*
    var s1=data[b].s/data[b].w,
        s2=data[a].s/data[a].w;
    if (s1<s2){return -1;}
    if (s1>s2){return 1;}
*/
  });

  data.sort(function(a,b){
    if (b.v<a.v){return -1;}
    if (b.v>a.v){return 1;}
  });
  for (j=0;j<p.length;j++){
      data2[j]=data[j].w;
  }
  data2.sort(function(a,b){
    if (b<a){return -1;}
    if (b>a){return 1;}
  });

/*
    var s1=b.s/b.w,
        s2=a.s/a.w;
    if (s1<s2){return -1;}
    if (s1>s2){return 1;}


["data",
{"s":53232.666666666664,"w":5683,"v":2333,"l":22093.666666666668},
{"s":52747.833333333336,"w":5661,"v":2326,"l":20911.333333333336},
{"s":53724.833333333336,"w":5702,"v":2293,"l":23294.333333333332},
{"s":52344.16666666667,"w":5710,"v":2079,"l":24321.666666666664},
{"s":50974.833333333336,"w":5610,"v":1729,"l":24395.333333333332}]
["data2",5710,5702,5683,5666,5661]
*/
// if (turn===4){console.log("p data",p,data);}
/*
  add_info("data",data[0],data[1],data[2],data[3],data[4]);
  add_info("data v",data[0].v,data[1].v,data[2].v,data[3].v,data[4].v);
  add_info("data w",data[0].w,data[1].w,data[2].w,data[3].w,data[4].w);
  add_info("data2",data2[0],data2[1],data2[2],data2[3],data2[4]);

  add_info(p[id[0][0]], p[id[0][1]], p[id[0][2]], p[id[0][3]], p[id[0][4]]);
*/
//  add_info(p[id2[0]], p[id2[1]], p[id2[2]], p[id2[3]], p[id2[4]]);


  l=p.length;
  if (1 || turn===4 || turn===8){
    s1=data[0].w;
  }
  else{
    s1=data[pat_id].l;
    s1=data[0].s/data[0].w;
  }

//    s1=data[0].w;
  if (l>5){l=5;}
  for (i=1;i<l && i<l;i++){
    if (1 || turn===4 || turn===8){
s2=data[i].w;
    }
    else{
      s2=data[i].l;
      s2=data[i].s/data[i].w;
    }
//s2=data[i].w;
    if (data[0].w>data[i].w*2){continue;}
    if (1 || turn!==8){
      if (s1<s2){
        pat_id=i;
        s1=s2;
      }
    }
    else{
      if (s1>s2){
        pat_id=i;
        s1=s2;
      }
    }
// pat_id=0;
/*
AI0>>STDOUT: ["data",
{"s":7030.666666666571,"w":1093,"v":745,"l":-125.66666666666715},
{"s":6689.166666666586,"w":1068,"v":727,"l":-143.83333333333337},
{"s":7116.833333333239,"w":1064,"v":692,"l":-149.66666666666669},
{"s":6409.666666666598,"w":1034,"v":606,"l":-235.6666666666655},
{"s":5311.333333333311,"w":936,"v":587,"l":-130.66666666666686}]
*/
/*
    else if (turn!=4 && turn!==8 && s1>s2){
      pat_id=i;
      s1=s2;
    }
*/
  }

  add_info("pat_id",pat_id,data[0]);

  for (i=0;i<targets_cou;i++){
    l=p[id[0][pat_id]][i];
    if (isHoliday){l/=2;}
    for (j=0;j<l;j++){
      fire.push(i);
    }
  }
  return fire;
}

function test2(pid,p,data,prev_pat,r,m1,m2,o){
  var l=p[pid].length,
      atk_copy=[],
      stl_copy=[],
      stl2_copy=[],
      apat="",
      spat=[],
      spat2=[],
      i=0,
      j=0,
      n=0,
      id=0,
      max=0,
      s=[];


  for (i=0; i<targets_cou; i++){
    atk_copy[i]=[];
    stl_copy[i]=stl[i];
    stl2_copy[i]=stl2[i];
//    if (pid===0){
      stl_copy[i]-=my_stl[i];
      stl2_copy[i]-=my_stl2[i];
//    }
    
    for (j=0; j<players_cou; j++){
      if (j===0 && pid===0){
        atk_copy[i][0]=my_atk[i];
      }
      else{
        atk_copy[i][j]=atk[i][j];
      }
      spat[players_cou*i+j]=0;
      spat2[players_cou*i+j]=0;
    }
    if (pid!==0){
      atk_copy[i][0]+=my_stl[i]*2;
      atk_copy[i][0]+=my_stl2[i]*2;
    }
  }

  if (turn===2 || turn===3 || turn===4 || turn===6 || turn===7 || turn===8){
    for (i=0; i<players_cou-1; i++){
      id=order[i];
//      if (i===0 && pid===0){continue;}
      max=2;
      while(max>0){
        if (exist[id]===1 && stl_copy[0]>0){
          n=0;
        }
        else{
          n=~~(Math.random() * targets_cou);
        }
        if (stl_copy[n]>0){
          atk_copy[n][id]+=2;
          stl_copy[n]--;
          max--;
          spat[players_cou*n+id]+=1;
        }
      }
    }
  }
  if (turn===4 || turn===8){
    for (i=0; i<players_cou-1; i++){
//      if (i===0 && pid===0){continue;}
      id=order[i];
      max=2;
      while(max>0){
        if (exist[id]===1 && stl2_copy[0]>0){
          n=0;
        }
        else{
          n=~~(Math.random() * targets_cou);
        }
        if (stl2_copy[n]>0){
          atk_copy[n][id]+=2;
          stl2_copy[n]--;
          max--;
          spat2[players_cou*n+id]+=1;
        }
      }
    }
  }

  for (i=0; i<players_cou; i++){
      if (i===pid){continue;}
      if (exist[i]===1){
        n=0;
      }
      else{
        n=~~(Math.random() * p[i].length);
      }
      for (j=0; j<targets_cou; j++){
        atk_copy[j][i]+=p[i][n][j];
      }
      apat+=n+",";
  }
  for (i=0;i<spat.length;i++){
    apat+=spat[i];
    apat+=spat2[i];
  }
//  add_info("apat",apat,spat,spat2);
  if (prev_pat[apat]){return;}
  prev_pat[apat]=1;
/*
["stl",[3,3,0,0,1,1],[2,0,1,2,2,1],[2,0,0,0,0,0],[2,0,0,0,0,0]]

["apat","120,113,30,000010000000102000010000000000020010020000110000",

[0,0,1,0, 0,0,1,2, 0,0,0,0, 0,0,0,0, 0,1,0,0, 0,1,0,0],
[0,0,0,0, 0,0,0,0, 0,1,0,0, 0,0,0,2, 0,0,2,0, 0,1,0,0]]

["apat","64,57,46,001000000000102000000001000100010011010000001100",

[0,1,0,0, 0,0,1,2, 0,0,0,0, 0,0,0,0, 0,1,0,0, 0,0,1,0],
[0,0,0,0, 0,0,0,0, 0,0,0,1, 0,1,0,1, 0,1,1,0, 0,0,1,0]]

["apat","0,104,139,000010000010101000000001000101000011000100000110",

[0,0,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1],
[0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,1,0,1,0,0,1,0]]
["cou2",3]

*/
  for (i=0; i<l;i++){
    for (j=0; j<targets_cou; j++){atk_copy[j][pid]+=p[pid][i][j];}
    for (j=0; j<players_cou; j++){s[j]=0;}
    battle(atk_copy,s,r);

    if (s[pid]===s[r[0]]){
      data[i].v++;
      data[i].w++;
      data[i].s+=s[pid];
//      if (s[1]<0 && s[2]<0 && s[3]<0){data[i].v++;}
    }
//    if (s[pid]>0){data[i].v++;}

    if (s[pid]<0){
      data[i].v--;
    }
    if (turn>4 && s[pid]<fixed_score[pid]){
      data[i].v--;
    }
    if (fixed_score[pid]>0 && s[pid]<fixed_score[pid]*2){
      data[i].l+=s[pid];
      data[i].v--;
    }
    if (fixed_score[pid]>0 && s[pid]<fixed_score[pid]){
      data[i].v--;
    }
//    if (s[pid]>0){data[i].v++;}
    if (pid===0){
      if (turn!==4 && turn!==8 && atk_copy[0][0]>0 && atk_copy[1][0]>0 && atk_copy[2][0]>0 && atk_copy[3][0]>0 && atk_copy[4][0]>0 && atk_copy[5][0]>0){data[i].v--;}
//      if (isHoliday===0 && turn!==4 && turn!==8 && p[pid][i][point_id[0]]>0){data[i].v-=10;}
//      if (isHoliday===0 && turn!==4 && turn!==8 && p[pid][i][point_id[1]]>0){data[i].v-=10;}

//      if (turn<4 && p[pid][i][point_id[3]]>0){data[i].v-=10;}

    }
    for (j=0; j<targets_cou; j++){atk_copy[j][pid]-=p[pid][i][j];}
  }
}

function battle(atk,score,rank){
  var max=0,
      min=0,
      top=[0],
      bottom=[0],
      tl=0,
      bl=0,
      tp=0,
      bp=0,
      i=0,
      j=0,
      a=0;
  for (i=0; i<targets_cou; i++){
    max=atk[i][0],
    min=atk[i][0],
    top=[0],
    bottom=[0];
    for (j=1; j<players_cou; j++){
      a=atk[i][j];
      if (max<a){
        max=a;
        top=[j];
      }
      else if (max===a){
        top[top.length]=j;
      }
      if (min>a){
        min=a;
        bottom=[j];
      }
      else if (min===a){
        bottom[bottom.length]=j;
      }
    }
    tl=top.length,
    bl=bottom.length,
    tp=points[i]/tl,
    bp=points[i]/bl;
    for (j=0; j<tl; j++){
      score[top[j]]+=tp;
    }
    for (j=0; j<bl; j++){
      score[bottom[j]]-=bp;
    }
  }
  if (turn>=5){
    for (i=0; i<players_cou; i++){
      score[i]+=fixed_score[i];
    }
  }
  rank.sort(function(a, b) {
      if (score[a] > score[b]) return -1;
      if (score[a] < score[b]) return 1;
  });
}
function turn_end(){
    if (turn==4){
      for (var i=0;i<targets_cou;i++){
          stl[i]=0;
          stl2[i]=0;
          my_stl[i]=0;
          my_stl2[i]=0;
      }
    }
    lineCount=0;
    isHoliday=1-isHoliday;
    turn++;
    if (debug){
      for (var i=0;i<info.length;i++) {
        send_msg(JSON.stringify(info[i]));
      }
      info=[];
    }
}

function dateWeekday() {
  var message = "";
  var f=test();
  for (var i = 0; i < 4; i++) {
    message += f[i];
    message += ' ';
  }
  message += f[i];
  send_msg(message);
}

function dateHoliday() {
  var message = "";
  var f=test();
  message += f[0];
  message += ' ';
  message += f[1];
  send_msg(message);
  if (turn==1 || turn==5){
    my_stl[f[0]]++;
    my_stl[f[1]]++;
  }
  else{
    my_stl2[f[0]]++;
    my_stl2[f[1]]++;
  }
}
function send_msg(msg){
  console.log(msg);
  rl.prompt();
}
function rand(n) {
  return ~~(Math.random() * n);
}


