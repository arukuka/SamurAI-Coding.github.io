public abstract class Player {
  public abstract void play(GameInfo info);
}