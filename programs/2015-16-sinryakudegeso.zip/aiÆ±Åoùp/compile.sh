#!/bin/sh
c++ -pthread -std=c++11 players.cpp -o sinryaku.exe
