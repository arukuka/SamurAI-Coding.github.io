gdc src/*.d -o main -g -fdebug
