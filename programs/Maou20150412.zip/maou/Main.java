package maou;


/**
 * サーバーで実行されるmain関数
 * @author taiyou
 *
 */
public class Main {

	public static void main(String[] args) {
		Player player = new MCPlayerLv8(0.95);
		player.serverPlay();
	}

}
