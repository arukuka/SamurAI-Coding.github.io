dmd src/*.d -ofout/main -g -debug
