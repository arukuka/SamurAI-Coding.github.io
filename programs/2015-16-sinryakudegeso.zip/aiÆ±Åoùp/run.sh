#!/bin/sh
./sinryaku.exe
