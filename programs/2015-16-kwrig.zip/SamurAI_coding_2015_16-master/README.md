# SamurAI_coding_2015_16

SamurAI_coding_2015_16 kwrigのソースコード

ぐちゃぐちゃなのは仕様

src/kwrig/IOBridgeクラスをメインにすると提出用AIになる


