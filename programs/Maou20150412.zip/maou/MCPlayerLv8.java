package maou;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import playout.MultiMovePlayout;
import playout.SmallMove;

/**
 * 本番で使ったプレイヤー
 * 
 * @author taiyou
 *
 */
public class MCPlayerLv8 extends Player {
	SamurAIRule rule;
	//少なくとも自分の新交点は確定できるので、保存し続ける。
	int myFriendlyPoint[];
	List<Integer> myLastNegoCountList;
	//休日に隠蔽された交渉回数。key = turn, value = 投票先
	Map<Integer,List<Integer>> negoMap;
	FirstBoost firstBoost = new FirstBoost();
	
	double victoryPoint[];
	double thinkingTimePercentage = 0.1;
	
	public MCPlayerLv8(double thinkingTimePercentage) {
		super();
		this.thinkingTimePercentage = thinkingTimePercentage;
	}
	
	@Override
	final public void init(SamurAIRule rule) {
		this.rule = rule;
		myFriendlyPoint = new int[rule.LanguageNum];
		myLastNegoCountList = new ArrayList<Integer>();
		victoryPoint = new double[rule.PlayerNum];
		
		negoMap = new HashMap<Integer,List<Integer>>();

		SmallMove.makeMove();
	}

	@Override
	final public int[] holidayAction(TurnInfo info) {
		int revealScore[][] = new int[rule.PlayerNum][rule.LanguageNum];
		//正確なところは大抵わからないが、revealをとりあえず使っておく。
		for(int i=0;i<rule.PlayerNum;i++){
			revealScore[i] = Arrays.copyOf(info.RevealedFriendlyPoint[i],rule.LanguageNum);
		}
		if(info.CurrentTurn == rule.MoreInfoOpenedTurn){
			assert(info.CurrentTurn == rule.MiddleScoringTurn+1);
			victoryPoint = MultiMovePlayout.calcVictoryPoint(revealScore, info.Rule);
			negoMap.clear();
		}
		int ret[] = action(info,revealScore);
		myLastNegoCountList.clear();
		for(int lang:ret){
			myFriendlyPoint[lang]+=rule.HolidayFriendlyPoint;
			myLastNegoCountList.add(lang);		}
		return ret;
	}

	@Override
	final public int[] weekdayAction(TurnInfo info) {
		int revealScore[][] = new int[rule.PlayerNum][rule.LanguageNum];
		//正確なところは大抵わからないが、revealをとりあえず使っておく。
		for(int i=0;i<rule.PlayerNum;i++){
			revealScore[i] = Arrays.copyOf(info.RevealedFriendlyPoint[i],rule.LanguageNum);
		}
		//隠蔽された休日情報を追加
		//ただし公開ターンの時に一度リセットされることに注意
		if(info.CurrentTurn >= 1){
			List<Integer> negoList = new ArrayList<Integer>();
			for(int i=0;i<info.NegotiatedCount.length;i++){
				for(int j=0;j<info.NegotiatedCount[i];j++){
					negoList.add(i);
				}
			}
			negoMap.put(info.CurrentTurn-1, negoList);
		}

		int ret[] = action(info,revealScore);
		myLastNegoCountList.clear();
		for(int lang:ret){
			myFriendlyPoint[lang]+=rule.WeekdayFriendlyPoint;
			myLastNegoCountList.add(lang);
		}
		return ret;
	}

	final public int[] action(final TurnInfo info,final int revealScore[][]){
		if(info.CurrentTurn == 0){
			//この時だけ限定のFirstBoost
			return firstBoost.get(rule.Attensions);
		}
		
		
		//knownScore作ってnegoMapから前回の自分の行動を確定済み情報として削除
		//ただし休日や初日には前回の交渉はnegoMapに登録されないので注意
		revealScore[0] = myFriendlyPoint;
		List<Integer> negoList = negoMap.get(info.CurrentTurn-1);
		if(negoList != null){
			for(int lang:myLastNegoCountList){
				negoList.remove(new Integer(lang));
			}
		}

		List<SmallMove> myMoveList = SmallMove.createMoveList(info.CurrentTurn);
		List<List<SmallMove>> everyMoveList = new ArrayList<List<SmallMove>>();
		everyMoveList.add(myMoveList);
		
		//UCB1を使ったプレイアウトを行うプレイヤーの数
		//全プレイヤーがUCB1を使って手を選ぶようにした時の勝率を調べようとした時のの名残
		int ucb1basedNum = 1;
//		int ucb1basedNum = rule.PlayerNum;
//		if(info.CurrentTurn == rule.TurnNum-1){
//			ucb1basedNum = rule.PlayerNum;
//		}

		for(int i=1;i<ucb1basedNum;i++){
			everyMoveList.add(SmallMove.createMoveList(info.CurrentTurn));
			Collections.shuffle(everyMoveList.get(i));
		}

		long start = System.currentTimeMillis();
		int totalPlayoutCount = 0;
		
		while(System.currentTimeMillis() - start < info.Rule.TurnLimitMilliseconds * thinkingTimePercentage){
			//毎回残り時間チェックをするのも無駄なので、100回のplayoutごとに残り時間チェックするように
			for(int i=0;i<100;i++){
				//プレイアウトのそれぞれの初手
				List<SmallMove> firstVoteList = new ArrayList<SmallMove>();

				//いろいろな方法を試したが、結局自身の手以外は推測せずに乱数的に選ぶのが良いっぽい
//				for(int j=0;j<rule.PlayerNum-1;j++){
				for(int j=0;j<ucb1basedNum;j++){
					SmallMove best = selectBestUcb1(everyMoveList.get(j), totalPlayoutCount);
					assert(best != null);
					firstVoteList.add(best);
				}

				MultiMovePlayout playout = new MultiMovePlayout(
						info.CurrentTurn,
						firstVoteList,
						rule,
						negoMap,
						revealScore,
						victoryPoint,
						thinkingTimePercentage<0.8
						);
				int winner = playout.playout();
				for(int j=0;j<firstVoteList.size();j++){
					SmallMove move = firstVoteList.get(j);
					
					if(j==winner){	//win
						move.feedBack(1.0);
					}else if(winner==-1){	//draw
						move.feedBack(0.05);
					}else {	//lose
						move.feedBack(0.0);
					}
				}
				
				totalPlayoutCount++;
			}
		}
		
		//一番選ばれたやつ
		SmallMove myMove = null;
		for(SmallMove move:myMoveList){
			if(myMove==null || move.getCount() > myMove.getCount()){
				myMove = move;
			}
		}
//		if(info.CurrentTurn == rule.TurnNum-1){
//			myMove.print();
//		}
		return myMove.move;
	}

	final public SmallMove selectBestUcb1(List<SmallMove> moveList,int totalPlayCount){
		SmallMove best = null;
		double bestUcb1 = Double.NEGATIVE_INFINITY;
		for(SmallMove move:moveList){
			double ucb1 = move.ucb1tune(totalPlayCount);
			if(ucb1 > bestUcb1){
				best = move;
				bestUcb1 = ucb1;
			}
		}
		return best;
	}
	
}

