cd $(dirname $0)
FilePath=`pwd`
${FilePath}/main ${FilePath}/Q0.csv ${FilePath}/Q1.csv ${FilePath}/Q2.csv
