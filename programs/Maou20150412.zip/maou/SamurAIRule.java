package maou;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * システムから明示的に与えられないルールセットと
 * 初期化時に与えられるルールセットの統合ルール
 * @author taiyou
 *
 */
public class SamurAIRule {
	public SamurAIRule(String rawText){
		String line[] = rawText.split("\n");
		String firstLine[] = line[0].split(" ");
		String secondLine[] = line[1].split(" ");

		TurnNum = Integer.parseInt(firstLine[0]);
		PlayerNum = Integer.parseInt(firstLine[1]);
		LanguageNum = Integer.parseInt(firstLine[2]);
		Attensions = new int[LanguageNum];
		for(int i=0;i<LanguageNum;i++){
			Attensions[i] = Integer.parseInt(secondLine[i]);
		}
		RouletteAttensionList = new ArrayList<Integer>();
		for(int a:Attensions){
			for(int i=0;i<a;i++){
				RouletteAttensionList.add(a);
			}
		}

		assert(TurnNum == 9);
		assert(PlayerNum == 4);
		assert(LanguageNum == 6);
	}

	public SamurAIRule(int TurnNum, int PlayerNum, int LanguageNum, int[] attensions){
		this.TurnNum = TurnNum;
		this.PlayerNum = PlayerNum;
		this.LanguageNum = LanguageNum;
		this.Attensions = Arrays.copyOf(attensions, LanguageNum);
		RouletteAttensionList = new ArrayList<Integer>();
		for(int i=0;i<attensions.length;i++){
			for(int j=0;j<attensions[i];j++){
				RouletteAttensionList.add(i);
			}
		}
	}
	/**
	 * 初期化時に与えられる系
	 * ただし注目度以外はシステム外で明示的に定義されているものでもある
	 */
	final public int TurnNum;
	final public int PlayerNum;
	final public int LanguageNum;
	final public int[] Attensions;
	final public List<Integer> RouletteAttensionList;

	/**
	 * システム外で明示的に定義されているもの
	 */
	final public int WeekdayNegotiationCount = 5;
	final public int HolidayNegotiationCount = 2;
	final public int WeekdayFriendlyPoint = 1;
	final public int HolidayFriendlyPoint = 2;
	final public long FirstLimitMilliseconds = 5000;
	final public long TurnLimitMilliseconds  = 1000;
	final public int  MiddleScoringTurn  = 4;	//中間スコア計算ターン
	final public long MoreInfoOpenedTurn = 5;	//最初を0ターン目とする。(与えられる値と異なる)

	final public int negotiationCount(int turn){
		return negotiationCount(turn%2==0);
	}
	final public int negotiationCount(boolean isWeekday){
		return isWeekday?WeekdayNegotiationCount:HolidayNegotiationCount;
	}
	final public int friendlyPoint(int turn){
		return friendlyPoint(turn%2==0);
	}
	final public int friendlyPoint(boolean isWeekday){
		return isWeekday?WeekdayFriendlyPoint:HolidayFriendlyPoint;
	}
}
