g++ -Wall -O3 -std=c++11 -DSUBMIT *.cpp -o prog
