gdc src/*.d -o main -frelease -O2 -march=native
