package maou;

import java.io.PrintWriter;
import java.util.Scanner;

/**
 * 自分用Playerの基底クラス
 * サーバーから送られてくるテキストの解釈や必要な出力をサポート
 * @author taiyou
 *
 */
public abstract class Player {
	abstract public void init(SamurAIRule rule);
	abstract public int[] holidayAction(TurnInfo info);
	abstract public int[] weekdayAction(TurnInfo info);
	
	Scanner scanner = new Scanner(System.in);
	PrintWriter writer = new PrintWriter(System.out, true);

	public void serverPlay(){
		writer.println("READY");
		writer.flush();

		readInitialData();
		
		while(!action()){
		}
		
		scanner.close();
		writer.close();
	}
	
	protected SamurAIRule baseRule;
	
	/**
	 * 初回に呼ばれる
	 */
	private void readInitialData()
	{
		
		int maxTurn = scanner.nextInt();
		int playersNum = scanner.nextInt();
		int languagesNum = scanner.nextInt();
		int attensions[] = new int[languagesNum];
		for (int i = 0; i < languagesNum; i++) {
			attensions[i] = scanner.nextInt();
		}
		
		baseRule = new SamurAIRule(maxTurn,playersNum,languagesNum,attensions);
		init(baseRule);
	}
	
	/**
	 * 二回目以降に呼ばれる
	 * @return 最終ターンだったか否か
	 */
	private boolean action(){
		int turn = scanner.nextInt();
		char day = scanner.next().charAt(0);
		int revealedScore[][] = new int[baseRule.PlayerNum][baseRule.LanguageNum];
		
		for (int i = 0; i < baseRule.LanguageNum; i++) {
			for (int j = 0; j < baseRule.PlayerNum; j++) {
				revealedScore[j][i] = scanner.nextInt();
			}
		}
		
		int realScore[] = new int[baseRule.LanguageNum];
		for (int i = 0; i < baseRule.LanguageNum; i++) {
			realScore[i] = scanner.nextInt();
		}
		
		int negotiatedCount[] = new int[baseRule.LanguageNum];
		if (day == 'D'||day =='W') {
			for (int i = 0; i < baseRule.LanguageNum; i++) {
				int selectedTimes = scanner.nextInt();
				negotiatedCount[i] = selectedTimes;
			}
		}
		
		TurnInfo info = new TurnInfo(baseRule,turn-1,day=='D'||day=='W',revealedScore,realScore,negotiatedCount);
		int[] ret = info.IsWeekday?weekdayAction(info):holidayAction(info);
		
		StringBuilder command = new StringBuilder();
		for(int i=0;i<ret.length;i++){
			command.append(ret[i]);
			if(i<ret.length-1){
				command.append(" ");
			}
		}
		writer.println(command.toString());
		writer.flush();
		
		return info.CurrentTurn+1 == baseRule.TurnNum;
	}
	
	public String toString(){
		return getClass().getTypeName();
	}
	
}
